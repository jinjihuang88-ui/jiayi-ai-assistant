bash: pg_dump: command not found
