import { cookies } from 'next/headers';
import { prisma } from './prisma';

const RCIC_SESSION_COOKIE = 'rcic_session_token';
const RCIC_ID_COOKIE = 'rcic_id'; // 与会员 user_id 一致，优先用 id cookie
const SESSION_EXPIRY_DAYS = 7;

export interface RCICUser {
  id: string;
  email: string;
  name: string;
  licenseNo: string | null;
  phone: string | null;
  avatar: string | null;
  isActive: boolean;
  isOnline: boolean;
  level?: string | null;
}

function toRCICUser(rcic: { id: string; email: string; name: string; licenseNo: string | null; phone: string | null; avatar: string | null; isActive: boolean; isOnline: boolean; level: string | null }) {
  return {
    id: rcic.id,
    email: rcic.email,
    name: rcic.name,
    licenseNo: rcic.licenseNo,
    phone: rcic.phone,
    avatar: rcic.avatar,
    isActive: rcic.isActive,
    isOnline: rcic.isOnline,
    level: rcic.level,
  };
}

// 获取当前登录的顾问（与会员一致：优先 rcic_id cookie，再兜底 session）
export async function getCurrentRCIC(): Promise<RCICUser | null> {
  try {
    const cookieStore = await cookies();
    const rcicId = cookieStore.get(RCIC_ID_COOKIE)?.value;
    if (rcicId) {
      const rcic = await prisma.rCIC.findUnique({
        where: { id: rcicId },
      });
      if (rcic && rcic.isActive) {
        await prisma.rCIC.update({
          where: { id: rcicId },
          data: { lastActiveAt: new Date(), isOnline: true },
        });
        return toRCICUser(rcic);
      }
    }
    const token = cookieStore.get(RCIC_SESSION_COOKIE)?.value;
    if (!token) return null;
    const session = await prisma.rCICSession.findUnique({
      where: { token },
      include: { rcic: true },
    });
    if (!session || session.expiresAt < new Date()) return null;
    await prisma.rCIC.update({
      where: { id: session.rcic.id },
      data: { lastActiveAt: new Date(), isOnline: true },
    });
    return toRCICUser(session.rcic);
  } catch (error) {
    console.error('Get current RCIC error:', error);
    return null;
  }
}

// 创建顾问会话
export async function createRCICSession(rcicId: string, userAgent?: string, ipAddress?: string) {
  const token = generateToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SESSION_EXPIRY_DAYS);

  const session = await prisma.rCICSession.create({
    data: {
      rcicId,
      token,
      expiresAt,
      userAgent,
      ipAddress,
    },
  });

  // 更新顾问在线状态
  await prisma.rCIC.update({
    where: { id: rcicId },
    data: { isOnline: true, lastActiveAt: new Date() },
  });

  return { token, expiresAt };
}

// 销毁顾问会话
export async function destroyRCICSession(token: string) {
  const session = await prisma.rCICSession.findUnique({
    where: { token },
  });

  if (session) {
    await prisma.rCICSession.delete({ where: { token } });

    // 检查是否还有其他活跃会话
    const otherSessions = await prisma.rCICSession.count({
      where: { rcicId: session.rcicId },
    });

    if (otherSessions === 0) {
      await prisma.rCIC.update({
        where: { id: session.rcicId },
        data: { isOnline: false },
      });
    }
  }
}

// 生成随机 token
function generateToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 64; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

// 生成验证码
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
