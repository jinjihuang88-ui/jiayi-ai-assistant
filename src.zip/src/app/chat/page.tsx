"use client";

import ChatHeader from "@/components/ChatHeader";
import Script from "next/script";
import Link from "next/link";

export default function ChatPage() {
  return (
    <>
      {/* Coze Chat SDK */}
      <Script
        src="https://lf-cdn.coze.cn/obj/unpkg/flow-platform/chat-app-sdk/1.2.0-beta.19/libs/cn/index.js"
        strategy="afterInteractive"
        onLoad={() => {
          // @ts-ignore
          new window.CozeWebSDK.WebChatClient({
            config: {
              type: "bot",
              bot_id: "7598385173373190195",
            },
            auth: {
              type: "token",
              onRefreshToken: async () => {
                const res = await fetch("/api/coze-token");
                const data = await res.json();
                return data.token;
              },
            },
            ui: {
              asstBtn: {
                isNeed: true, // 仅使用官方浮窗
              },
              base: {
                lang: "zh-CN",
              },
            },
          });
        }}
      />

      <ChatHeader />

      <main className="min-h-screen bg-slate-50 text-slate-900">
        <div className="max-w-5xl mx-auto px-6 py-24">
          
          {/* Heading */}
          <h1 className="text-4xl md:text-5xl font-semibold leading-tight">
            AI 加拿大移民咨询  
            <span className="block text-2xl md:text-3xl text-slate-500 mt-3 font-normal">
              AI-Powered Canadian Immigration Consultation
            </span>
          </h1>

          {/* Intro */}
          <p className="mt-8 text-lg text-slate-600 max-w-2xl leading-relaxed">
            基于加拿大移民局（IRCC）官方公开数据的智能咨询服务，  
            帮助你理解可行路径、关键条件以及下一步方向。
          </p>

          <p className="mt-3 text-sm text-slate-500 max-w-2xl leading-relaxed">
            An AI-assisted consultation built on official Canadian public data,  
            designed to help you understand viable pathways, key requirements, and next steps.
          </p>

          {/* Info Cards */}
          <div className="mt-16 grid md:grid-cols-3 gap-8">
            {[
              {
                title: "官方数据驱动",
                titleEn: "Official Data–Driven",
                desc: "分析基于 IRCC 及加拿大官方劳工系统的公开信息。",
                descEn:
                  "Analysis based on publicly available data from IRCC and official Canadian labour sources.",
              },
              {
                title: "轻量咨询方式",
                titleEn: "Focused, Step-by-Step",
                desc: "不使用冗长问卷，根据你的问题逐步判断。",
                descEn:
                  "No lengthy forms. Each conversation focuses on one key question at a time.",
              },
              {
                title: "隐私优先设计",
                titleEn: "Privacy-First Design",
                desc: "不要求上传证件或不必要的个人敏感信息。",
                descEn:
                  "No document uploads or unnecessary personal data required.",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="rounded-xl bg-white border border-slate-200 p-8"
              >
                <div className="font-medium mb-1">{item.title}</div>
                <div className="text-xs text-slate-500 mb-3">
                  {item.titleEn}
                </div>
                <div className="text-sm text-slate-600 leading-relaxed">
                  {item.desc}
                </div>
                <div className="text-xs text-slate-500 mt-2 leading-relaxed">
                  {item.descEn}
                </div>
              </div>
            ))}
          </div>

          {/* Status Callout */}
          <div className="mt-20 rounded-2xl border border-slate-200 bg-white p-10 flex items-center justify-between">
            <div>
              <div className="font-semibold text-lg">
                AI 咨询已就绪
              </div>
              <div className="text-sm text-slate-600 mt-1">
                请使用右下角的 AI 咨询按钮开始对话
              </div>

              <div className="text-xs text-slate-500 mt-3">
                The AI consultant is ready.  
                Use the chat button in the bottom-right corner to begin.
              </div>
            </div>

            <div className="text-sm text-slate-500 leading-relaxed text-right">
              基于加拿大官方公开数据 · 注重隐私与信息安全
              <br />
              <span className="text-xs text-slate-400">
                Powered by official Canadian public data · Privacy-first by design
              </span>
            </div>
          </div>

          {/* Secondary CTA */}
          <div className="mt-16 text-sm text-slate-500">
            想先了解整体可能性？
            <Link
              href="/assessment"
              className="ml-2 text-blue-600 hover:underline"
            >
              去做免费 AI 评估 →
            </Link>
            <span className="block text-xs text-slate-400 mt-2">
              Want a broader overview first? Start with a free AI assessment.
            </span>
          </div>
        </div>
      </main>
    </>
  );
}
